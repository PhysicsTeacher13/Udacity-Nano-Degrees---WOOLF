# print("Hello, ESP32!")
from joystick import Joystick
from servo import Servo
import time
from machine import Pin

print("Starting Program")

gain = 1 # set default gain

# initialize servos 
servo_pan1 = Servo(pin=13) # Pan Cam 1
servo_tilt1 = Servo(pin=14) # Tilt Cam 1
servo_pan2 = Servo(pin=16) # Pan Cam 2
servo_tilt2 = Servo(pin=2) # Tilt Cam 2

print("Servo setup complete!")

# initialize joystick in interrupt mode
joystick = Joystick(xAxis=32, yAxis=33, buttonPin=34, mode='interrupt') 

print("Joystick setup complete!")

# initialize slide switch (digital input)
slide_switch = Pin(15, Pin.IN, Pin.PULL_UP)

# initialize Led (digital output)
led1 = Pin(4, Pin.OUT)
led2 = Pin(23, Pin.OUT)

print("Switch and Led 1 and Led 2 setup complete!")

def request_gain():
    global gain
    while True:
        try:
            gain_input = input("Enter a gain value from 1 to 10: ")
            gain = int(gain_input)
            if 1 <= gain <= 10:
                print(f"Gain set to: {gain}")
                break
            else:
                print("Invalid input, Gain must be between 1 and 10")
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 10")

def move_servo(joystick_state, pan, tilt):
    # LM, LU, LD, RM, RU, RD, MM, MU, MD

    if len(joystick_state) != 2:
        return
    x_dir = joystick_state[0]
    y_dir = joystick_state[1]

    # Pan Control
    
    if x_dir == 'L':
        pan.left()
    elif x_dir == 'R':
        pan.right()
    
    # Tilt Control

    if y_dir == 'U':
        tilt.left()
    elif y_dir == 'D':
        tilt.right()

while True:
    joystick_state = joystick.read()

    button_pressed = joystick.is_button_pressed()

    if button_pressed:
        print("Joystick button pressed!")
        request_gain()

    switch_state = slide_switch.value()

    if switch_state == 1:
        move_servo(joystick_state, servo_pan1, servo_tilt1)
        led1.value(1)
        led2.value(0)
    else:
        move_servo(joystick_state, servo_pan2, servo_tilt2)
        led1.value(0)
        led2.value(1)
    
    time.sleep(0.1/gain)


from machine import Pin, PWM

class Servo:
    def __init__(self, pin: int, min_us=550, max_us=2400):
        # Write your initialization code here
        self.pwm = PWM(Pin(pin))
        self.pwm.freq(50) # 50Hz
        # PW range in microseconds
        self.min_us = min_us # 0 deg pos
        self.max_us = max_us # 180 deg pos
        
        # Start at center
        self.current_angle = 90 # center position default
        self.goto(90) # default position

        # We pre-populated the min and max values for the servo
        # pass
    
    # Convert Duty cycle 
    def _us_to_duty(self, us: int) -> int:
        return int((us * 65535) // 20000) # convert microseconds to duty unsigned 16 for 50 Hz PWM

    # Move the servo to the requested angle
    def goto(self, angle: int):
        # Write your code here
        angle = max(0, min(180, angle))
        self.current_angle = angle # set current angle
        # convert angle to microseconds
        pulse_us = self.min_us + (angle * (self.max_us - self.min_us) // 180)
        duty = self._us_to_duty(pulse_us)
        self.pwm.duty_u16(duty) # duty cycle 
        
        # pass

    # Move the servo to the left, the requested angle
    def left(self):
        # Write your code here
        self.goto(self.current_angle - 1) # keep within bounds using goto (1 deg left)
    
        # pass

    # Move the servo to the right, the requested angle
    def right(self):
        # Write your code here
        self.goto(self.current_angle + 1) # keep withing bounds using goto (1 deg right)
        
        # pass
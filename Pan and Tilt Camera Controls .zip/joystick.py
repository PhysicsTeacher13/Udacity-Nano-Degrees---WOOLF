from machine import ADC, Pin, Timer

class Joystick:
    def __init__(self, xAxis: int, yAxis: int, buttonPin: int, mode: str):
        # Write your code here
        self.x_adc = ADC(Pin(xAxis))
        self.y_adc = ADC(Pin(yAxis))

        # Configure the ADC with attenuation
        self.x_adc.atten(ADC.ATTN_11DB) #full 0-3.3 V
        self.y_adc.atten(ADC.ATTN_11DB) #full 0-3.3 V

        # initalize button pin
        self.button = Pin(buttonPin, Pin.IN, Pin.PULL_UP)

        # initalize variables for joystick state
        self.x_value = 2048
        self.y_value = 2048
        self.mode = mode
        self.timer = None

        if mode == 'interrupt':
            # periodically read joystick data
            self.timer = Timer(-1)
            self.timer.init(period=100, mode=Timer.PERIODIC, callback=self.read_callback)
    
    def read_callback(self, timer):
        # timer callback to read values of joystick
        self.x_value = self.x_adc.read()
        self.y_value = self.y_adc.read()


        # pass

    # This function reads the joystick and returns the joystick state:
    # L: left    R: Right    U: Up    D: Down    M: Middle
    def read(self):
        if self.mode == 'polling':
            # read analog values 
            self.x_value = self.x_adc.read()
            self.y_value = self.y_adc.read()
        #
        threshold = 200
        center = 2048

        # Modify to include diagonal movement of joystick (RM, LM, RU, LU, RD, LD)

        dx = self.x_value - center
        dy = self.y_value - center

        # X axis dir

        if dx < -threshold:
            x_dir = 'L'
        elif dx > threshold:
            x_dir = 'R'
        else:
            x_dir = 'M'

        if dy < -threshold:
            y_dir = 'U'
        elif dy > threshold:
            y_dir = 'D'
        else:
            y_dir = 'M'
        
        # Centered -> MM
        return x_dir + y_dir 

        if (abs(self.x_value - center) < threshold and abs(self.y_value - center) < threshold):
            return 'M' # Middle
        elif self.x_value < (center - threshold):
            return 'L' # Left
        elif self.x_value > (center + threshold):
            return 'R' # Right
        elif self.y_value < (center - threshold):
            return 'U' # Up
        elif self.y_value > (center + threshold):
            return 'D' # Down
        else:
            return 'ERROR'
        
    def is_button_pressed(self):
        # True if button pressed
        return not self.button.value()
    
        # pass